#!/bin/sh

# replace 0000000000000000000000000000000000000000 with your address

# mine to hardbios.com
./bzminer -a ixi -r rig_name -w 0000000000000000000000000000000000000000 -p http://ixian.hardbios.com:8081

# mine to changeling.biz
#./bzminer -a ixi -r rig_name -w 0000000000000000000000000000000000000000 -p http://ixian.changeling.biz:8081

# mine to mineixi.com
#./bzminer -a ixi -r rig_name -w 0000000000000000000000000000000000000000 -p http://mineixi.com:80

read -p "Press [Enter] key to start continue..."