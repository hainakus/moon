#!/bin/sh

# May need Admin/Root privileges
./bzminer --no_watchdog --oc_reset_all

read -p "Press [Enter] key to start continue..."